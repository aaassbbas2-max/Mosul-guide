# دليل الموصل | Mosul Guide — مشروع Android (Capacitor)

التطبيق نفسه (index.html + data/) كما هو، ولف داخل Capacitor ليصبح تطبيق Android مستقلاً يعمل دون متصفح.
مجلد review/ والنسخ الاحتياطية تبقى في المشروع ولا تدخل داخل APK.

## أسهل طريقة للحصول على APK (دون تثبيت أي برنامج): GitHub Actions
1. أنشئ حساباً مجانياً على github.com ثم مستودعاً جديداً (Private).
2. ارفع كل محتويات هذا المجلد (بما فيها المجلد المخفي .github).
3. افتح تبويب Actions ← Build Android ← Run workflow.
4. بعد 5–10 دقائق نزّل Artifact باسم mosul-guide-android ففيه:
   - mosul-guide-debug.apk  ← للتثبيت المباشر على هاتفك
   - mosul-guide-release-unsigned.aab ← للنشر على Google Play (يحتاج توقيعاً، انظر أدناه)

## البناء على حاسوبك (Windows/Mac/Linux)
المتطلبات: Node 20+ و JDK 21 و Android Studio (لتثبيت Android SDK) ومتغير ANDROID_HOME.
الأمر: bash scripts/build-android.sh   ← النتائج في dist/

## تثبيت APK على Samsung Galaxy S25 Ultra
1. انقل mosul-guide-debug.apk إلى الهاتف (كابل USB أو Telegram أو Drive).
2. افتح الملف من تطبيق «ملفاتي». إن ظهر تحذير: اضغط «الإعدادات» وفعّل «السماح من هذا المصدر».
3. اضغط «تثبيت» ثم «فتح». إن اعترض Play Protect اضغط «تثبيت على أي حال».
ملاحظة: نسخة debug موقّعة بمفتاح تجريبي، مناسبة للتجربة والاستخدام الشخصي، وليست للنشر في Google Play.

## النشر على Google Play (لاحقاً)
1. أنشئ مفتاح توقيع واحتفظ به ونسخته الاحتياطية: keytool -genkey -v -keystore mosul-guide.jks -alias mosul -keyalg RSA -keysize 2048 -validity 10000
2. وقّع الملف: jarsigner -keystore mosul-guide.jks mosul-guide-release-unsigned.aab mosul
3. ارفعه في Google Play Console (حساب مطوّر برسم لمرة واحدة 25$).
لا ترفع ملف .jks إلى GitHub ولا تضع كلمات المرور في الكود.

## البيانات
- بيانات المراجعة والتوثيق وكلمة مرور لوحة التحكم محفوظة داخل التطبيق على كل هاتف (localStorage) وتبقى بعد إغلاقه وتحديثه، وتُحذف عند إلغاء تثبيته. صدّرها من لوحة التحكم بانتظام.
- لتحديث البيانات الأساسية: عدّل data/places.json وdata/sources.json ثم أعد البناء.
