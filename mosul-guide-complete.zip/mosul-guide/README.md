# دليل الموصل | Mosul Guide — المرحلة 1 (MVP)

## التشغيل محلياً
cd mosul-guide && python3 -m http.server 8000   ثم افتح http://localhost:8000

## النشر المجاني (يلزم HTTPS ليعمل التثبيت)
ارفع مجلد mosul-guide كما هو إلى Netlify Drop أو Cloudflare Pages أو GitHub Pages.
على Android: افتح الرابط في Chrome ← ⋮ ← "تثبيت التطبيق".

## البيانات
data/places.json هو المصدر الأولي. بعد تعديل الأماكن من لوحة التحكم اضغط "تصدير JSON"
واستبدل به data/places.json ثم أعد النشر. لا تضف هاتفاً أو إحداثيات أو صوراً دون تحقق وإذن.
صيغة CSV: id,name_ar,name_en,type,subtype,description,district,address,phone,whatsapp,lat,lng,hours,price,family,delivery,parking,verified,source,updated,added
type = restaurant | cafe | hotel | tourism | market   —   family/delivery/parking = 1 أو 0

## حدود هذه المرحلة
- البيانات والتقييمات والمفضلة محفوظة في متصفح كل جهاز، وليست مشتركة بين المستخدمين.
- كلمة مرور لوحة التحكم تجريبية على الجهاز، وليست حماية حقيقية.
- خريطة مضمّنة (OpenStreetMap) في صفحة المكان فقط عند توفر الإحداثيات؛ ولا توجد خريطة تجمع كل الأماكن بعد.
