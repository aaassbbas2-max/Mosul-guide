#!/usr/bin/env bash
# يتطلب: Node 20+ و JDK 21 و Android SDK (ANDROID_HOME). النتائج في مجلد dist/
set -euo pipefail
cd "$(dirname "$0")/.."
npm install
node scripts/prepare-www.js
[ -d android ] || npx cap add android
npx @capacitor/assets generate --android --iconBackgroundColor '#12284A' --splashBackgroundColor '#12284A'
npx cap sync android
( cd android && chmod +x gradlew && ./gradlew assembleDebug bundleRelease )
mkdir -p dist
cp android/app/build/outputs/apk/debug/app-debug.apk dist/mosul-guide-debug.apk
cp android/app/build/outputs/bundle/release/app-release.aab dist/mosul-guide-release-unsigned.aab
ls -la dist
