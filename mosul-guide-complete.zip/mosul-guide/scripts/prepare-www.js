// ينسخ ملفات التطبيق المنشورة فقط إلى www. مجلد review/ والنسخ الاحتياطية لا تُضمَّن في APK.
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, ".."), out = path.join(root, "www");
fs.rmSync(out, { recursive: true, force: true });
const copy = (rel) => { const s = path.join(root, rel), d = path.join(out, rel);
  fs.mkdirSync(path.dirname(d), { recursive: true }); fs.cpSync(s, d, { recursive: true }); };
["index.html", "manifest.webmanifest", "sw.js", "icons", "data/places.json", "data/sources.json"].forEach(copy);
console.log("www جاهز:", fs.readdirSync(out).join(", "));
